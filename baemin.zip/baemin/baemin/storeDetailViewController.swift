//
//  storeDetailViewController.swift
//  baemin
//
//  Created by CHOI on 2022/06/01.
//

import UIKit

class storeDetailViewController: UIViewController {

    @IBOutlet weak var storeTableView: UITableView!
    @IBOutlet weak var cartButton: UIButton!
    @IBAction func cartButton(_ sender: Any) {
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "cartViewController") as? cartViewController else { return }
        
        vc.cartList = self.cartList
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    var menuList = menuData()
    var cartList = CartList()
//    var cartManager = CartManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        storeTableView.delegate = self
        storeTableView.dataSource = self

        storeTableView.register(UINib(nibName: "storeDetailTableViewCell", bundle: nil), forCellReuseIdentifier: "storeDetailTableViewCell")
        
        buttonShadow(name: cartButton)
        cartButton.setTitle(String(cartList.products.count), for: .normal)
        print("cartbutton loaded")
//        self.navigationItem.backBarButtonItem?.title = ""
    }
    
    func buttonShadow(name: UIButton) {
        let button = name
        button.layer.shadowColor = UIColor.gray.cgColor
        button.layer.shadowOffset = CGSize(width: 0, height: 1)
        button.layer.shadowRadius = 3
        button.layer.shadowOpacity = 0.5
    }
}

extension storeDetailViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuList.menus.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = storeTableView.dequeueReusableCell(withIdentifier: "storeDetailTableViewCell", for: indexPath) as? storeDetailTableViewCell else {
            return UITableViewCell()
        }
        
        let row = indexPath.row
        let menu = menuList.getMenuData(row)
        
        cell.menuName.text = menu.name
        cell.img.image = UIImage(named: menu.img)
        cell.menuDescription.text = menu.description
        cell.menuPrice.text = String(menu.price)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        func saveMenu(alert: UIAlertAction!) {
            cartList.addToCart(menu: menuForCart(name: menuList.getMenuData(indexPath.row).name, price: menuList.getMenuData(indexPath.row).price))
            cartButton.setTitle(String(cartList.products.count), for: .normal)
        }
        
        // 장바구니 담기 alert 띄우기
        let alertTitle = "장바구니"
        let message = "장바구니에 \(menuList.getMenuData(indexPath.row).name) 담기"
        let alert = UIAlertController(title: alertTitle, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "네", style: .default, handler: { (alert) -> Void in
            saveMenu(alert: alert)
        }))
        alert.addAction(UIAlertAction(title: "아니오", style: .cancel, handler: nil))

        present(alert, animated: true, completion: nil)
        
        storeTableView.deselectRow(at: indexPath, animated: true)
    }
}

struct menuForCart {
    let name: String
    let price: Int
}
