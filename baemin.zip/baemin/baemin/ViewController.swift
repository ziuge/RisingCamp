//
//  ViewController.swift
//  baemin
//
//  Created by CHOI on 2022/05/30.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var buttonBM1: UIButton!
    @IBOutlet weak var buttonBD: UIButton!
    @IBOutlet weak var buttonPJ: UIButton!
    @IBOutlet weak var buttonBmart: UIButton!
    @IBOutlet weak var buttonMealkit: UIButton!
    @IBOutlet weak var buttonStore: UIButton!
    @IBOutlet weak var buttonLive: UIButton!
    @IBOutlet weak var buttonPresent: UIButton!
    @IBOutlet weak var buttonKorea: UIButton!
    @IBAction func buttonBM1(_ sender: Any) {
//        print("pressed")
//        let bmoneViewController = self.storyboard?.instantiateViewController(withIdentifier: "BmoneViewController") as! BmoneViewController
//        self.present(bmoneViewController, animated: true, completion: nil)
//        print("presented")
    }
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        UINavigationBarAppearance().backgroundColor = .systemMint
//        UINavigationBar.appearance().barTintColor = .systemMint
//        let appearance = UINavigationBarAppearance()
//        appearance.configureWithOpaqueBackground()
//        appearance.backgroundColor = .systemMint
//        UINavigationBar.standardAppearance = appearance
////        navigationBar.standardAppearance = appearance
//        UINavigationBar.scrollEdgeAppearance = UINavigationBar.standardAppearance
////        navigationBar.scrollEdgeAppearance = navigationBar.standardAppearance

        buttonShadow(name: buttonBM1)
        buttonShadow(name: buttonBD)
        buttonShadow(name: buttonPJ)
        buttonShadow(name: buttonBmart)
        buttonShadow(name: buttonMealkit)
        buttonShadow(name: buttonStore)
        buttonShadow(name: buttonLive)
        buttonShadow(name: buttonPresent)
        buttonShadow(name: buttonKorea)
        
    }
    
    func buttonShadow(name: UIButton) {
        let button = name
        button.layer.shadowColor = UIColor.gray.cgColor
        button.layer.shadowOffset = CGSize(width: 0, height: 1)
        button.layer.shadowRadius = 3
        button.layer.shadowOpacity = 0.3
    }


}


