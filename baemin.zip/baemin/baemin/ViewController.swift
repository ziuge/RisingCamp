//
//  ViewController.swift
//  baemin
//
//  Created by CHOI on 2022/05/30.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var buttonBM1: UIButton!
    @IBOutlet weak var buttonBD: UIButton!
    @IBOutlet weak var buttonPJ: UIButton!
    @IBOutlet weak var buttonBmart: UIButton!
    @IBOutlet weak var buttonMealkit: UIButton!
    @IBOutlet weak var buttonStore: UIButton!
    @IBOutlet weak var buttonLive: UIButton!
    @IBOutlet weak var buttonPresent: UIButton!
    @IBOutlet weak var buttonKorea: UIButton!
    @IBAction func buttonBM1(_ sender: Any) {
//        print("pressed")
//        let bmoneViewController = self.storyboard?.instantiateViewController(withIdentifier: "BmoneViewController") as! BmoneViewController
//        self.present(bmoneViewController, animated: true, completion: nil)
//        print("presented")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let newNavBarAppearance = customNavBarAppearance()
        navigationController!.navigationBar.scrollEdgeAppearance = newNavBarAppearance
        navigationController!.navigationBar.compactAppearance = newNavBarAppearance
        navigationController!.navigationBar.standardAppearance = newNavBarAppearance
        if #available(iOS 15.0, *) {
            navigationController!.navigationBar.compactScrollEdgeAppearance = newNavBarAppearance
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        buttonShadow(name: buttonBM1)
        buttonShadow(name: buttonBD)
        buttonShadow(name: buttonPJ)
        buttonShadow(name: buttonBmart)
        buttonShadow(name: buttonMealkit)
        buttonShadow(name: buttonStore)
        buttonShadow(name: buttonLive)
        buttonShadow(name: buttonPresent)
        buttonShadow(name: buttonKorea)
    }
    
    func customNavBarAppearance() -> UINavigationBarAppearance {
        let customNavBarAppearance = UINavigationBarAppearance()
        
        // Apply a mint background.
        customNavBarAppearance.configureWithOpaqueBackground()
        customNavBarAppearance.backgroundColor = .systemMint
        
        // Apply white colored normal and large titles.
        customNavBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
//        customNavBarAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]

        // Apply white color to all the nav bar buttons.
        let barButtonItemAppearance = UIBarButtonItemAppearance(style: .plain)
        barButtonItemAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor.white]
        barButtonItemAppearance.disabled.titleTextAttributes = [.foregroundColor: UIColor.lightText]
        barButtonItemAppearance.highlighted.titleTextAttributes = [.foregroundColor: UIColor.label]
        barButtonItemAppearance.focused.titleTextAttributes = [.foregroundColor: UIColor.white]
        customNavBarAppearance.buttonAppearance = barButtonItemAppearance
        customNavBarAppearance.backButtonAppearance = barButtonItemAppearance
        customNavBarAppearance.doneButtonAppearance = barButtonItemAppearance
        
        return customNavBarAppearance
    }
    
    func buttonShadow(name: UIButton) {
        let button = name
        button.layer.shadowColor = UIColor.gray.cgColor
        button.layer.shadowOffset = CGSize(width: 0, height: 1)
        button.layer.shadowRadius = 3
        button.layer.shadowOpacity = 0.3
    }
    


}


