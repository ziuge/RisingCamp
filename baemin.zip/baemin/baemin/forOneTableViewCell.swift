//
//  forOneTableViewCell.swift
//  baemin
//
//  Created by CHOI on 2022/05/31.
//

import UIKit

class forOneTableViewCell: UITableViewCell {
    
    @IBOutlet weak var storeImage: UIImageView!
    @IBOutlet weak var LabelText: UILabel!
    @IBOutlet weak var rateStar: UILabel!
    @IBOutlet weak var deliverTime: UILabel!
    @IBOutlet weak var minPrice: UILabel!
    
//    func configureWithItem(item: storeListModel) {
//        storeImage?.image = item.image
//        LabelText?.text = item.name
//        rateStar?.text = item.rating
//        deliverTime?.text = item.deliverTime
//        minPrice?.text = item.minPrice
//    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        resize(label: LabelText)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func resize (label: UILabel) {
        let newSize = label.intrinsicContentSize
        label.frame.size = newSize
    }
}
