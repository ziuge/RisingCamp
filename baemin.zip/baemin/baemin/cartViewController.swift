//
//  cartViewController.swift
//  baemin
//
//  Created by CHOI on 2022/06/02.
//

import UIKit

class cartViewController: UIViewController {
    
    @IBOutlet weak var cartTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cartTableView.delegate = self
        cartTableView.dataSource = self
        cartTableView.register(UINib(nibName: "cartTableViewCell", bundle: nil), forCellReuseIdentifier: "cartTableViewCell")
    }
    
}

extension cartViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = cartTableView.dequeueReusableCell(withIdentifier: "cartTableViewCell", for: indexPath) as? cartTableViewCell else {
            return UITableViewCell()
        }
        
        return cell
    }
    
    
    
    
}
