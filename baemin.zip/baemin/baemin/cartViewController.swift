//
//  cartViewController.swift
//  baemin
//
//  Created by CHOI on 2022/06/02.
//

import UIKit

class cartViewController: UIViewController {
    
    @IBOutlet weak var cartTableView: UITableView!
    
    var cartList = CartList()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cartTableView.delegate = self
        cartTableView.dataSource = self
        cartTableView.register(UINib(nibName: "cartTableViewCell", bundle: nil), forCellReuseIdentifier: "cartTableViewCell")
        
        self.cartList.products = cartList.products
        self.cartList.total = cartList.total
    }
    
}

extension cartViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cartList.products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = cartTableView.dequeueReusableCell(withIdentifier: "cartTableViewCell", for: indexPath) as? cartTableViewCell else {
            return UITableViewCell()
        }
        
        let row = indexPath.row
        let menu = self.cartList.getCartData(row)
        
        cell.cartMenuName.text = menu.name
        cell.cartMenuPrice.text = String(menu.price)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        func deleteMenu(alert: UIAlertAction!) {
            cartList.removeFromCart(menu: menuForCart(name: cartList.getCartData(indexPath.row).name, price: cartList.getCartData(indexPath.row).price))
            self.cartTableView.reloadData()
        }

        // 장바구니 담기 alert 띄우기
        let alertTitle = "장바구니"
        let message = "장바구니에서 \(cartList.getCartData(indexPath.row).name) 제거"
        let alert = UIAlertController(title: alertTitle, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "네", style: .default, handler: { (alert) -> Void in
            deleteMenu(alert: alert)
        }))
        alert.addAction(UIAlertAction(title: "아니오", style: .cancel, handler: nil))

        present(alert, animated: true, completion: nil)
        
//        self.cartTableView.reloadData()
        
//        cartTableView.deselectRow(at: indexPath, animated: true)
    }
    
    func addToCart(menu: menuForCart) {
        cartList.products.append(menu)
        cartList.total += menu.price
        print("addToCart")
        print(cartList.products)
        print(cartList.total)
    }

    func removeFromCart(menu: menuForCart) {
        cartList.products = cartList.products.filter {$0.name != menu.name}
        cartList.total -= menu.price
        print("removeFromCart")
        print(cartList.products)
        print(cartList.total)
    }
    
}
