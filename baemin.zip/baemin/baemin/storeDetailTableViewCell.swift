//
//  storeDetailTableViewCell.swift
//  baemin
//
//  Created by CHOI on 2022/06/01.
//

import UIKit

class storeDetailTableViewCell: UITableViewCell {
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var menuName: UILabel!
    @IBOutlet weak var menuDescription: UILabel!
    @IBOutlet weak var menuPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}

struct menuListModel {
    let storeName: String?
    let img: String
    let name: String
    let description: String
    let price: Int
}

struct menuData {
    let menus: [menuListModel] = [
        menuListModel(storeName: "태산 커피", img: "menu1", name: "리얼 바닐라 라떼", description: "마다가스카르산 알이 꽉찬 바닐라빈으로 직접 만든 시럽으로 완성한 인기 메뉴", price: 6000),
        menuListModel(storeName: "태산 커피", img: "menu2", name: "태산 왕 크로플", description: "크로플 X 2개를 하나로 가격은 더 저렴하게~ 사이즈는 더 크게 :)", price: 7000),
        menuListModel(storeName: "태산 커피", img: "menu3", name: "아메리카노", description: "콜롬비아, 과테말라, 인도네시아 블랜딩", price: 6000),
        menuListModel(storeName: "태산 커피", img: "menu4", name: "태산 크로플", description: "태산만의 시그니처로 새롭게 개발한 겉바 속촉은 기본, 적당한 단맛 & 감칠맛 :D", price: 3800)
    ]
    
    func getMenuData(_ row: Int) -> menuListModel {
        return menus[row]
    }
}
