//
//  cartTableViewCell.swift
//  baemin
//
//  Created by CHOI on 2022/06/02.
//

import UIKit

class cartTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
