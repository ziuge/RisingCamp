//
//  storeListModel.swift
//  baemin
//
//  Created by CHOI on 2022/05/31.
//

import UIKit

struct storeListModel {
    let name: String?
    let img: String?
    let rating: String?
    let deliverTime: String?
    let minPrice: String?
    
//    init(name: String, img: String, rating: String, deliverTime: String, minPrice: String) {
//        self.name = "태산"
//        self.img = "태산"
//        self.rating = "5.0"
//        self.deliverTime = "15분~25분"
//        self.minPrice = "최소주문금액 12,000원"
//    }
}
