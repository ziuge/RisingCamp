//
//  BmoneViewController.swift
//  baemin
//
//  Created by CHOI on 2022/05/31.
//

import UIKit

class BmoneViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var bm1AdScrollView: UIScrollView!
    @IBOutlet weak var bm1AdPageControl: UIPageControl!
    
    var movies: [String] = ["bad-boys","joker","hollywood"]
    var frame = CGRect.zero
    
    override func viewDidLoad() {
        super.viewDidLoad()

        bm1AdPageControl.numberOfPages = movies.count
        setupScreens()

        bm1AdScrollView.delegate = self
    }

    func setupScreens() {
        for index in 0..<movies.count {
            // 1. The images will be positioned side-by-side in the frame of the scroll view.
            frame.origin.x = bm1AdScrollView.frame.size.width * CGFloat(index)
            frame.size = bm1AdScrollView.frame.size
            
            // 2. The images are loaded and added to the scroll view.
            let imgView = UIImageView(frame: frame)
            imgView.image = UIImage(named: movies[index])

            self.bm1AdScrollView.addSubview(imgView)
        }

        // 3. The contentsize is the total size of the scrollview.
        bm1AdScrollView.contentSize = CGSize(width: (bm1AdScrollView.frame.size.width * CGFloat(movies.count)), height: bm1AdScrollView.frame.size.height)
        bm1AdScrollView.delegate = self
    }

    // page control
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageNumber = scrollView.contentOffset.x / scrollView.frame.size.width
        bm1AdPageControl.currentPage = Int(pageNumber)
    }
}
