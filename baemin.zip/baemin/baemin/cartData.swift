//
//  cartData.swift
//  baemin
//
//  Created by CHOI on 2022/06/02.
//

import Foundation

class CartList {
    var products: [menuForCart] = []
    var total: Int = 0
    
    func getCartData(_ row: Int) -> menuForCart {
        return products[row]
    }
    
    func addToCart(menu: menuForCart) {
        products.append(menu)
        total += menu.price
        print("addToCart")
        print(products)
        print(total)
    }

    func removeFromCart(menu: menuForCart) {
        products = products.filter {$0.name != menu.name}
        total -= menu.price
        print("removeFromCart")
        print(products)
        print(total)
    }
}

//class CartManager {
//    var cartList = CartList()
//
//    func addToCart(menu: menuForCart) {
//        cartList.products.append(menu)
//        cartList.total += menu.price
//        print("addToCart")
//        print(cartList.products)
//        print(cartList.total)
//    }
//
//    func removeFromCart(menu: menuForCart) {
//        cartList.products = cartList.products.filter {$0.name != menu.name}
//        cartList.total -= menu.price
//        print("removeFromCart")
//        print(cartList.products)
//        print(cartList.total)
//    }

//    func getCartData(_ row: Int) -> menuForCart {
//        print("row", row)
//        print(cartList.products)
//        return cartList.products[row]
//    }

//}
