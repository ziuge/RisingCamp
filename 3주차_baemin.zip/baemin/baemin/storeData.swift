//
//  storeData.swift
//  baemin
//
//  Created by CHOI on 2022/05/31.
//

import UIKit

struct storeData {
    let stores: [storeListModel] = [
        storeListModel(name: "태산 커피", img: "태산", rating: "5.0", deliverTime: "배민1 15~25분", minPrice: "최소주문 15,000원 · 배달팁 0원~2,000원 · 1.2km"),
        storeListModel(name: "쥬씨", img: "쥬씨", rating: "4.9", deliverTime: "배민1 16~26분", minPrice: "최소주문 7,000원 · 배달팁 0원~3,900원 · 0.9km"),
        storeListModel(name: "리틀하노이", img: "리틀하노이", rating: "4.7", deliverTime: "배민1 17~27분", minPrice: "최소주문 8,500원 · 배달팁 3,450원~4,450원 · 1.9km"),
        storeListModel(name: "봉구스밥버거", img: "봉구스밥버거", rating: "4.9", deliverTime: "배민1 15~25분", minPrice: "최소주문 8,000원 · 배달팁 2,450원~3,450원 · 1.1km"),
        storeListModel(name: "왕돈까스 왕냉면", img: "왕돈까스 왕냉면", rating: "4.6", deliverTime: "배민1 12~22분", minPrice: "최소주문 6,000원 · 배달팁 3,450원~4,450원 · 1.2km"),
        storeListModel(name: "프롬하츠커피", img: "프롬하츠커피", rating: "4.9", deliverTime: "배민1 18~28분", minPrice: "최소주문 12,000원 · 배달팁 0원~2,000원 · 0.9km")
    ]
    
    func getStoreData(_ row: Int) -> storeListModel {
        return stores[row]
    }
}
