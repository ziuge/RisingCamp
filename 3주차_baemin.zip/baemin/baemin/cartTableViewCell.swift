//
//  cartTableViewCell.swift
//  baemin
//
//  Created by CHOI on 2022/06/02.
//

import UIKit

class cartTableViewCell: UITableViewCell {

    @IBOutlet weak var cartMenuName: UILabel!
    @IBOutlet weak var cartMenuPrice: UILabel!
//    @IBOutlet weak var cartDeleteButton: UIButton!
//    @IBAction func cartDeleteButton(_ sender: Any) {
//        print("delete")
//    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
