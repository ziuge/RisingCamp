//
//  BmoneViewController.swift
//  baemin
//
//  Created by CHOI on 2022/05/31.
//

import UIKit

class BmoneViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var bm1AdScrollView: UIScrollView!
    @IBOutlet weak var bm1AdPageControl: UIPageControl!
    
    var movies: [String] = ["IMG_0644.jpg","IMG_0645.jpg","IMG_0646.jpg"]
    var frame = CGRect.zero
    
    override func viewDidLoad() {
        super.viewDidLoad()

        bm1AdPageControl.numberOfPages = movies.count
        setupScreens()

        bm1AdScrollView.delegate = self
        
        let newNavBarAppearance = customNavBarAppearance()
        navigationController!.navigationBar.scrollEdgeAppearance = newNavBarAppearance
        navigationController!.navigationBar.compactAppearance = newNavBarAppearance
        navigationController!.navigationBar.standardAppearance = newNavBarAppearance
        navigationController!.navigationBar.tintColor = .black
        if #available(iOS 15.0, *) {
            navigationController!.navigationBar.compactScrollEdgeAppearance = newNavBarAppearance
        }
//        self.navigationController?.navigationBar.tintColor = .black
//        self.navigationController?.navigationBar
//        UINavigationBar.appearance().backIndicatorImage = UIImage(named: "arrow.backward")
//        UINavigationBar.appearance().backIndicatorTransitionMaskImage = UIImage(named: "arrow.backward")
        

    }
    
    func customNavBarAppearance() -> UINavigationBarAppearance {
        let customNavBarAppearance = UINavigationBarAppearance()
        
        // Apply a red background.
        customNavBarAppearance.configureWithOpaqueBackground()
        customNavBarAppearance.backgroundColor = .white
        
        // Apply white colored normal and large titles.
        customNavBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.black]
//        customNavBarAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]

        // Apply white color to all the nav bar buttons.
        let barButtonItemAppearance = UIBarButtonItemAppearance(style: .plain)
        barButtonItemAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor.black]
        barButtonItemAppearance.disabled.titleTextAttributes = [.foregroundColor: UIColor.darkText]
        barButtonItemAppearance.highlighted.titleTextAttributes = [.foregroundColor: UIColor.label]
        barButtonItemAppearance.focused.titleTextAttributes = [.foregroundColor: UIColor.black]
        customNavBarAppearance.buttonAppearance = barButtonItemAppearance
        customNavBarAppearance.backButtonAppearance = barButtonItemAppearance
        customNavBarAppearance.doneButtonAppearance = barButtonItemAppearance
        
        return customNavBarAppearance
    }


    func setupScreens() {
        for index in 0..<movies.count {
            // 1. The images will be positioned side-by-side in the frame of the scroll view.
            frame.origin.x = bm1AdScrollView.frame.size.width * CGFloat(index)
            frame.size = bm1AdScrollView.frame.size
            
            // 2. The images are loaded and added to the scroll view.
            let imgView = UIImageView(frame: frame)
            imgView.image = UIImage(named: movies[index])

            self.bm1AdScrollView.addSubview(imgView)
        }

        // 3. The contentsize is the total size of the scrollview.
        bm1AdScrollView.contentSize = CGSize(width: (bm1AdScrollView.frame.size.width * CGFloat(movies.count)), height: bm1AdScrollView.frame.size.height)
        bm1AdScrollView.delegate = self
    }

    // page control
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageNumber = scrollView.contentOffset.x / scrollView.frame.size.width
        bm1AdPageControl.currentPage = Int(pageNumber)
    }
}
