//
//  forOneViewController.swift
//  baemin
//
//  Created by CHOI on 2022/05/31.
//

import UIKit

class forOneViewController: UIViewController {
    
    @IBOutlet weak var forOneTableView: UITableView!
    
    var storeList = storeData()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        forOneTableView.delegate = self
        forOneTableView.dataSource = self
        
        forOneTableView.register(UINib(nibName: "forOneTableViewCell", bundle: nil), forCellReuseIdentifier: "forOneTableViewCell")
        
        forOneTableView.rowHeight = UITableView.automaticDimension;
        forOneTableView.estimatedRowHeight = 130;
        
    }
}

extension forOneViewController : UITableViewDataSource, UITableViewDelegate {
 
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return storeList.stores.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = forOneTableView.dequeueReusableCell(withIdentifier: "forOneTableViewCell", for: indexPath) as? forOneTableViewCell else {
            return UITableViewCell()
        }
        
        let row = indexPath.row
        let store = storeList.getStoreData(row)

        cell.LabelText.text = store.name
        cell.storeImage.image = UIImage(named: store.img!)
        cell.rateStar.text = store.rating
        cell.deliverTime.text = store.deliverTime
        cell.minPrice.text = store.minPrice
        
        return cell
    }
    
    // 셀 row height 유동적으로 변하도록
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    // 클릭 감지 부분
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        print("가게 이름: \(storeList.getStoreData(indexPath.row).name)")
        performSegue(withIdentifier: "showStoreDetail", sender: indexPath.row)
        forOneTableView.deselectRow(at: indexPath, animated: true)
    }

}
