//
//  CartDelegate.swift
//  starbucks
//
//  Created by CHOI on 2022/05/27.
//

import Foundation

protocol CartDelegate {
    func alarmCartIsFilled(itemCount: Int)
}
