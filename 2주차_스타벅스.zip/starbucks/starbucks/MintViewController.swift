//
//  MintViewController.swift
//  starbucks
//
//  Created by CHOI on 2022/05/27.
//

import UIKit

class MintViewController: UIViewController {
    
    @IBOutlet weak var uiTextField: UITextField!
    
    @IBAction func didTapButton(_ sender: Any) {
        let data : String = uiTextField.text!
        
        let cartViewController = self.storyboard?.instantiateViewController(withIdentifier: "cartViewController") as! cartViewController
        
        cartViewController.result = data
        
        print(data)
        self.present(cartViewController, animated: true, completion: nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
}
