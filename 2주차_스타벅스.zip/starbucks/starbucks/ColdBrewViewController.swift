//
//  ColdBrewViewController.swift
//  starbucks
//
//  Created by CHOI on 2022/05/25.
//

import UIKit

class ColdBrewViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func isMintTapped(_ sender: Any) {
        let mintViewController = self.storyboard?.instantiateViewController(withIdentifier: "MintViewController") as! MintViewController
        
        self.present(mintViewController, animated: true, completion: nil)
    }
}
