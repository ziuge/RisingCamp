//
//  OrderViewController.swift
//  starbucks
//
//  Created by CHOI on 2022/05/25.
//

import UIKit

class OrderViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func isColdBrewTapped(_ sender: Any) {
        
        let coldBrewViewController = self.storyboard?.instantiateViewController(withIdentifier: "ColdBrewViewController") as! ColdBrewViewController
        
        self.present(coldBrewViewController, animated: true, completion: nil)
    }
    
}
