//
//  cartViewController.swift
//  starbucks
//
//  Created by CHOI on 2022/05/27.
//

import UIKit

class cartViewController: UIViewController {

    @IBOutlet weak var uiResult: UILabel!
    
    var result: String? = "0"

    override func viewDidLoad() {
        super.viewDidLoad()
        
        uiResult.text = result
    }

}
