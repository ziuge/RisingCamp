//
//  SecondViewController.swift
//  ThreadPractice
//
//  Created by CHOI on 2022/06/07.
//

import UIKit
import AVFoundation

var backgroundSoundEffect: AVAudioPlayer?
var buttonSoundEffect: AVAudioPlayer?

class SecondViewController: UIViewController {
    
    @IBOutlet weak var timerUI: UILabel!
    @IBOutlet weak var scoreUI: UILabel!
    
    @IBOutlet weak var b1: UIButton!
    @IBOutlet weak var b2: UIButton!
    @IBOutlet weak var b3: UIButton!
    @IBOutlet weak var b4: UIButton!
    @IBOutlet weak var b5: UIButton!
    @IBOutlet weak var b6: UIButton!
    @IBOutlet weak var b7: UIButton!
    @IBOutlet weak var b8: UIButton!
    @IBOutlet weak var b9: UIButton!
    @IBOutlet weak var b10: UIButton!
    @IBOutlet weak var b11: UIButton!
    @IBOutlet weak var b12: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        timerText()
        playBackgroundSound()
    }
    
    var secondsRemaining = 15
    var score: Int = 0
    
    // 타이머
    @objc func timerText() {
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [self] (Timer) in
            if self.secondsRemaining > 0 {
//                print("\(secondsRemaining)")
                timerUI.text = "타이머 : \(self.secondsRemaining)"
                self.secondsRemaining -= 1
            } else {
                timerUI.text = "타이머 : \(self.secondsRemaining)"
                print("timer end")
                Timer.invalidate()
                gameEnd()
            }
        }
    }
    
    @objc func scoreText() {
        scoreUI.text = "점수 : \(self.score)"
    }
    
    // 붕어빵 배열
    let boong = [b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12]
    
    // 붕어빵별 시간 재기 - 10초에서 시작
    var bTimeCount = Array(repeating: 10, count: 12)
    
    // 붕어빵별 상태
    let stateArray = ["빈 틀", "안 익음", "익음", "탐"]
    var bState = [String](repeating: "빈 틀", count: 12)
    
    // 붕어빵별 타이머
    var timerCounting = [Bool](repeating: false, count: 12)
    
    var timer1: Timer = Timer()
    var timer2: Timer = Timer()
    var timer3: Timer = Timer()
    var timer4: Timer = Timer()
    var timer5: Timer = Timer()
    var timer6: Timer = Timer()
    var timer7: Timer = Timer()
    var timer8: Timer = Timer()
    var timer9: Timer = Timer()
    var timer10: Timer = Timer()
    var timer11: Timer = Timer()
    var timer12: Timer = Timer()
    
    func showToast(message : String, font: UIFont = UIFont.systemFont(ofSize: 14.0)){
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height-100, width: 150, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        toastLabel.textColor = UIColor.white
        toastLabel.font = font
        toastLabel.textAlignment = .center;
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 20;
        toastLabel.clipsToBounds = true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: { toastLabel.alpha = 0.0 }, completion: {(isCompleted) in toastLabel.removeFromSuperview()})
        
    }
    
    // 음악 재생
    func playBackgroundSound() {
        //    🎵Music provided by 브금대통령
        //    🎵Track : 동물농장 - https://youtu.be/XomFqZ25Jp4
        let url = Bundle.main.url(forResource: "bgm", withExtension: "mp3")
        if let url = url{
            do {
                backgroundSoundEffect = try AVAudioPlayer(contentsOf: url)
                backgroundSoundEffect!.prepareToPlay()
                backgroundSoundEffect!.play()
            } catch let error {
                print(error.localizedDescription)
            }
        }
    }
    
    // 효과음 설정
    //    Sound Effects and Music provided by Gfx Sounds.
    //    https://gfxsounds.com/free-sound-effects
    
    // 효과음1 (빈 틀에 반죽을 넣거나, 붕어빵이 다 익은 채로 꺼냈을 때)
    func popButtonSound() {
        let url = Bundle.main.url(forResource: "popButton", withExtension: "mp3")
        buttonSoundEffect = try! AVAudioPlayer(contentsOf: url!)
        buttonSoundEffect!.play()
    }
    
    // 효과음2 (덜 익거나 탄 채로 꺼냈을 때)
    func failButtonSound() {
        let url = Bundle.main.url(forResource: "failButton", withExtension: "mp3")
        buttonSoundEffect = try! AVAudioPlayer(contentsOf: url!)
        buttonSoundEffect!.play()
    }

    
    // 게임 종료
    func gameEnd() {
        backgroundSoundEffect?.stop()
        // 게임 종료 Alert 띄우기
        let alertTitle = "게임 종료"
        let score = self.score
        let message = "점수는 \(score)점 입니다."
        let alert = UIAlertController(title: alertTitle, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            // 이전 화면으로 돌아가기
            self.dismiss(animated: true, completion: nil)
        }))
        
        present(alert, animated: true, completion: nil)

        // timer 모두 멈추기
        timer1.invalidate()
        timer2.invalidate()
        timer3.invalidate()
        timer4.invalidate()
        timer5.invalidate()
        timer6.invalidate()
        timer7.invalidate()
        timer8.invalidate()
        timer9.invalidate()
        timer10.invalidate()
        timer11.invalidate()
        timer12.invalidate()
    }
    
    @objc func bTimer(bnum: Int, bButton: UIButton, speed: String) {
        // 익을 때 시간, 탈 때 시간
        var first: Int = 5
        var second: Int = 1
        
        if speed == "Fast" {
            first = 6
            second = 3
        } else if speed == "Slow" {
            first = 4
            second = 0
        }
        
        bTimeCount[bnum] -= 1

//        print("\(bnum + 1)번 붕어빵 \(bTimeCount[bnum])초")

        // "안 익음" 상태에서 first초가 남으면 "익음" 상태로 바꾸고 이미지 변경하기
        if bTimeCount[bnum] == first && bState[bnum] == stateArray[1] {
            self.bState[bnum] = stateArray[2]
            DispatchQueue.main.sync {
                bButton.setImage(UIImage(named: "boong3"), for: .normal)
            }
            print("\(bnum + 1)번 붕어빵 \(bTimeCount[bnum])초, \(bState[bnum])")
        }

        // "익음" 상태에서 second초가 남으면 "탐" 상태로 바꾸고 이미지 변경하기
        if bTimeCount[bnum] == second && bState[bnum] == stateArray[2] {
            self.bState[bnum] = stateArray[3]
            DispatchQueue.main.sync {
                bButton.setImage(UIImage(named: "boong4"), for: .normal)
            }
            print("\(bnum + 1)번 붕어빵 \(bTimeCount[bnum])초, \(bState[bnum])")
        }
    }
    
    // 붕어빵 꺼낼 때 붕어빵틀 이미지, 현황, 타이머 리셋하기
    func reset(bnum: Int, bButton: UIButton) {
        bButton.setImage(UIImage(named: "boong1"), for: .normal)
        self.bState[bnum] = stateArray[0]
        timerCounting[bnum] = false
        bTimeCount[bnum] = 10
    }
    
    // 각 타이머 설정
    @objc func bTimer1() { bTimer(bnum: 0, bButton: b1, speed: "Slow") }
    @objc func bTimer2() { bTimer(bnum: 1, bButton: b2, speed: "normal") }
    @objc func bTimer3() { bTimer(bnum: 2, bButton: b3, speed: "Slow") }
    @objc func bTimer4() { bTimer(bnum: 3, bButton: b4, speed: "normal") }
    @objc func bTimer5() { bTimer(bnum: 4, bButton: b5, speed: "Fast") }
    @objc func bTimer6() { bTimer(bnum: 5, bButton: b6, speed: "normal") }
    @objc func bTimer7() { bTimer(bnum: 6, bButton: b7, speed: "normal") }
    @objc func bTimer8() { bTimer(bnum: 7, bButton: b8, speed: "Fast") }
    @objc func bTimer9() { bTimer(bnum: 8, bButton: b9, speed: "normal") }
    @objc func bTimer10() { bTimer(bnum: 9, bButton: b10, speed: "Slow") }
    @objc func bTimer11() { bTimer(bnum: 10, bButton: b11, speed: "normal") }
    @objc func bTimer12() { bTimer(bnum: 11, bButton: b12, speed: "Slow") }


    // MARK: - 버튼 별 설정
    @IBAction func b1(_ sender: Any) {
        if(bState[0] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b1.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[0] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[0] = true
                let runLoop = RunLoop.current
                timer1 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer1), userInfo: nil, repeats: true)
                
                while timerCounting[0]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[0] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 0, bButton: b1)
            timer1.invalidate()
        } else if (bState[0] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 0, bButton: b1)
            timer1.invalidate()
        } else if (bState[0] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 0, bButton: b1)
            timer1.invalidate()
        }
    }

    
    @IBAction func b2(_ sender: Any) {
        if(bState[1] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b2.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[1] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[1] = true
                let runLoop = RunLoop.current
                timer2 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer2), userInfo: nil, repeats: true)
                
                while timerCounting[1]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[1] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 1, bButton: b2)
            timer2.invalidate()
        } else if (bState[1] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 1, bButton: b2)
            timer2.invalidate()
        } else if (bState[1] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 1, bButton: b2)
            timer2.invalidate()
        }
    }
    
    @IBAction func b3(_ sender: Any) {
        if(bState[2] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b3.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[2] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[2] = true
                let runLoop = RunLoop.current
                timer3 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer3), userInfo: nil, repeats: true)
                
                while timerCounting[2]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[2] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 2, bButton: b3)
            timer3.invalidate()
        } else if (bState[2] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 2, bButton: b3)
            timer3.invalidate()
        } else if (bState[2] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 2, bButton: b3)
            timer3.invalidate()
        }
    }
    
    @IBAction func b4(_ sender: Any) {
        if(bState[3] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b4.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[3] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[3] = true
                let runLoop = RunLoop.current
                timer4 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer4), userInfo: nil, repeats: true)
                
                while timerCounting[3]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[3] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 3, bButton: b4)
            timer4.invalidate()
        } else if (bState[3] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 3, bButton: b4)
            timer4.invalidate()
        } else if (bState[3] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 3, bButton: b4)
            timer4.invalidate()
        }
    }
    
    @IBAction func b5(_ sender: Any) {
        if(bState[4] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b5.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[4] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[4] = true
                let runLoop = RunLoop.current
                timer5 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer5), userInfo: nil, repeats: true)
                
                while timerCounting[4]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[4] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 4, bButton: b5)
            timer5.invalidate()
        } else if (bState[4] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 4, bButton: b5)
            timer5.invalidate()
        } else if (bState[4] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 4, bButton: b5)
            timer5.invalidate()
        }
    }
    
    @IBAction func b6(_ sender: Any) {
        if(bState[5] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b6.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[5] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[5] = true
                let runLoop = RunLoop.current
                timer6 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer6), userInfo: nil, repeats: true)
                
                while timerCounting[5]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[5] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 5, bButton: b6)
            timer6.invalidate()
        } else if (bState[5] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 5, bButton: b6)
            timer6.invalidate()
        } else if (bState[5] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 5, bButton: b6)
            timer6.invalidate()
        }
    }
    
    @IBAction func b7(_ sender: Any) {
        if(bState[6] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b7.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[6] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[6] = true
                let runLoop = RunLoop.current
                timer7 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer7), userInfo: nil, repeats: true)
                
                while timerCounting[6]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[6] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 6, bButton: b7)
            timer7.invalidate()
        } else if (bState[6] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 6, bButton: b7)
            timer7.invalidate()
        } else if (bState[6] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 6, bButton: b7)
            timer7.invalidate()
        }
    }
    
    @IBAction func b8(_ sender: Any) {
        if(bState[7] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b8.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[7] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[7] = true
                let runLoop = RunLoop.current
                timer8 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer8), userInfo: nil, repeats: true)
                
                while timerCounting[7]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[7] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 7, bButton: b8)
            timer8.invalidate()
        } else if (bState[7] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 7, bButton: b8)
            timer8.invalidate()
        } else if (bState[7] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 7, bButton: b8)
            timer8.invalidate()
        }
    }
    
    @IBAction func b9(_ sender: Any) {
        if(bState[8] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b9.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[8] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[8] = true
                let runLoop = RunLoop.current
                timer9 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer9), userInfo: nil, repeats: true)
                
                while timerCounting[8]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[8] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 8, bButton: b9)
            timer9.invalidate()
        } else if (bState[8] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 8, bButton: b9)
            timer9.invalidate()
        } else if (bState[8] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 8, bButton: b9)
            timer9.invalidate()
        }
    }
    
    @IBAction func b10(_ sender: Any) {
        if(bState[9] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b10.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[9] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[9] = true
                let runLoop = RunLoop.current
                timer10 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer10), userInfo: nil, repeats: true)
                
                while timerCounting[9]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[9] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 9, bButton: b10)
            timer10.invalidate()
        } else if (bState[9] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 9, bButton: b10)
            timer10.invalidate()
        } else if (bState[9] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 9, bButton: b10)
            timer10.invalidate()
        }
    }
    
    @IBAction func b11(_ sender: Any) {
        if(bState[10] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b11.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[10] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[10] = true
                let runLoop = RunLoop.current
                timer11 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer11), userInfo: nil, repeats: true)
                
                while timerCounting[10]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[10] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 10, bButton: b11)
            timer11.invalidate()
        } else if (bState[10] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 10, bButton: b11)
            timer11.invalidate()
        } else if (bState[10] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 10, bButton: b11)
            timer11.invalidate()
        }
    }
    
    @IBAction func b12(_ sender: Any) {
        if(bState[11] == "빈 틀") {
            popButtonSound()
            // 반죽 넣기 - 사진 변경: 안 익음
            self.b12.setImage(UIImage(named: "boong2"), for: .normal)
            self.bState[11] = stateArray[1]
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                timerCounting[11] = true
                let runLoop = RunLoop.current
                timer12 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(bTimer12), userInfo: nil, repeats: true)
                
                while timerCounting[11]{
                    runLoop.run(until: Date().addingTimeInterval(0.1))
                }
            }
        } else if (bState[11] == stateArray[1]){
            failButtonSound()
            // 스코어 낮게
            showToast(message: "아직 안 익었어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 11, bButton: b12)
            timer8.invalidate()
        } else if (bState[11] == stateArray[2]) {
            popButtonSound()
            showToast(message: "맛있게 익었어요!")
            score += 100
            scoreText()
            reset(bnum: 11, bButton: b12)
            timer12.invalidate()
        } else if (bState[11] == stateArray[3]) {
            failButtonSound()
            showToast(message: "너무 탔어요 ㅠㅠ")
            score -= 100
            scoreText()
            reset(bnum: 11, bButton: b12)
            timer12.invalidate()
        }
    }
}
