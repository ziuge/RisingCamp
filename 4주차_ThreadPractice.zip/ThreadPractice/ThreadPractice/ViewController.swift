//
//  ViewController.swift
//  ThreadPractice
//
//  Created by CHOI on 2022/06/05.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var startButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        startButton.tintColor = .systemOrange
        // Do any additional setup after loading the view.
    }
    
}

