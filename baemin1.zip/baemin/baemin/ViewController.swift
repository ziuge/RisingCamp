//
//  ViewController.swift
//  baemin
//
//  Created by CHOI on 2022/05/30.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var buttonBM1: UIButton!
    @IBOutlet weak var buttonBD: UIButton!
    @IBOutlet weak var buttonPJ: UIButton!
    @IBOutlet weak var buttonBmart: UIButton!
    @IBOutlet weak var buttonMealkit: UIButton!
    @IBOutlet weak var buttonStore: UIButton!
    @IBOutlet weak var buttonLive: UIButton!
    @IBOutlet weak var buttonPresent: UIButton!
    @IBOutlet weak var buttonKorea: UIButton!
    @IBAction func buttonBM1(_ sender: Any) {
    }
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UINavigationBarAppearance().backgroundColor = .systemMint

        buttonBM1.layer.cornerRadius = 40
    }


}

